import React from "react";

const Tooltip = props => {
  return <span className='tooltiptext'>{props.desc}</span>;
};

export default Tooltip;
